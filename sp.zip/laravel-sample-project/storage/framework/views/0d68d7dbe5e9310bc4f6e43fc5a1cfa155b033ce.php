<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>hiii</h2>
    <a class="btn btn-sm btn-primary" href="<?php echo e(route('category.create')); ?>" style="float: right;margin-bottom: 10px;">Add</a>
    <table class="table">
        <thead>
        <th>Title</th>
        <th>Description</th>
        </thead>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cat->title); ?></td>
            <td><?php echo e($cat->description); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>