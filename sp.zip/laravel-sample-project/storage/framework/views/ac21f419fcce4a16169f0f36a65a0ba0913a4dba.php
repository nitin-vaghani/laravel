<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Add Category</h2>
    <form method="post" action="<?php echo e(route('category.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>"/>
        </div>
        <div class="form-group">
            <label for="description">Description :</label>
            <input type="text" class="form-control" name="description" value="<?php echo e(old('description')); ?>"/>
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>