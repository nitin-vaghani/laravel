@extends('layouts.app')
@section('content')
<div class="container">
    <h2>hiii</h2>
    <a class="btn btn-sm btn-primary" href="{{route('category.create')}}" style="float: right;margin-bottom: 10px;">Add</a>
    <table class="table">
        <thead>
        <th>Title</th>
        <th>Description</th>
        </thead>
        @foreach($category as $cat)
        <tr>
            <td>{{$cat->title}}</td>
            <td>{{$cat->description}}</td>
        </tr>
        @endforeach
    </table>
</div>
@endsection