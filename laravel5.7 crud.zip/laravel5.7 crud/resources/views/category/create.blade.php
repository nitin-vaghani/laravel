@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Add Category</h2>
    <form method="post" action="{{ route('category.store')}}">
        @csrf
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" name="title" value="{{ old('title')}}"/>
        </div>
        <div class="form-group">
            <label for="description">Description :</label>
            <input type="text" class="form-control" name="description" value="{{ old('description')}}"/>
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
    </form>
</div>
@endsection