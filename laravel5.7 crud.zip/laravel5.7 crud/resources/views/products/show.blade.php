@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Product detail</h2>
    <div class="form-group">
        <label for="name">Product Name:</label> {{$product->title}}
    </div>
    <div class="form-group">
        <label for="description">Description :</label> {{$product->description}}
    </div>
    <a class="btn btn-sm btn-primary" href="{{route('products.index')}}">Back</a>
</div>
@endsection