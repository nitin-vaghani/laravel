<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Product List </h2>
    <a class="btn btn-sm btn-primary" href="<?php echo e(route('products.create')); ?>" style="float: right;margin-bottom: 10px;">Add Product</a>
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th colspan="2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('products.show',$product->id)); ?>"><?php echo e($product->title); ?></a></td>
                <td><?php echo e($product->description); ?></td>
                <td><a href="<?php echo e(route('products.edit',$product->id)); ?>">Edit</a></td>
                <td>
                    <form method="post" action="<?php echo e(route('products.destroy',$product->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>