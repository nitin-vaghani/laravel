<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Product detail</h2>
    <div class="form-group">
        <label for="name">Product Name:</label> <?php echo e($product->title); ?>

    </div>
    <div class="form-group">
        <label for="description">Description :</label> <?php echo e($product->description); ?>

    </div>
    <a class="btn btn-sm btn-primary" href="<?php echo e(route('products.index')); ?>">Back</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>