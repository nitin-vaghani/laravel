@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Product List </h2>
    <a class="btn btn-sm btn-primary" href="{{route('products.create')}}" style="float: right;margin-bottom: 10px;">Add Product</a>
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th colspan="2">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
            <tr>
                <td><a href="{{ route('products.show',$product->id)}}">{{$product->title}}</a></td>
                <td>{{$product->description}}</td>
                <td><a href="{{ route('products.edit',$product->id)}}">Edit</a></td>
                <td>
                    <form method="post" action="{{route('products.destroy',$product->id)}}">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {{ $products->links() }}
</div>
@endsection